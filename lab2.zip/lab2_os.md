# 一、示例代码编译及运行
## 1.  &nbsp;nosync-ex.c
代码及其运行截图:
```
#include<stdio.h>
#include <pthread.h>
int sum=0;
void *thread(void*){
int i;
for(i=0;i<1000000;i++)
sum+=1;
}
int main(void){
pthread_t tid1,tid2;
pthread_create(&tid1,NULL,thread,NULL);
pthread_create(&tid2,NULL,thread,NULL);
pthread_join(tid1,NULL);
pthread_join(tid2,NULL);
printf("1000000+1000000=%d\n",sum);
return (0);
}
```
![alt text](image\1.png)
## 2.  &nbsp;mutex-ex.c
代码及其运行截图:
```
#include<stdio.h>
#include <pthread.h>
int sum =0;
pthread_mutex_t mutex;
void *thread() {
int i;
for (i = 0; i< 1000000; i++) {
pthread_mutex_lock(&mutex);
sum +=1;
pthread_mutex_unlock(&mutex);
}}
int main(){
pthread_t tid1,tid2;
pthread_mutex_init(&mutex, NULL);
pthread_create(&tid1, NULL, thread, NULL);
pthread_create(&tid2, NULL, thread, NULL);
pthread_join(tid1, NULL);
pthread_join(tid2, NULL);
printf ("1000000 + 1000000 = %d\n", sum);
return (0);}
```
![alt text](image\2.png)




## 3.  &nbsp;sem-ex.c
代码及其运行截图:
```
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
int sum=0;
sem_t sem;
void *thread(void*) {
int i;
for (i = 0;i< 1000000; i++) {
sem_wait(&sem);
sum += 1;
sem_post(&sem);}}
int main(void) {
pthread_t tid1, tid2;
sem_init(&sem, 0, 1);
pthread_create(&tid1,NULL, thread, NULL);
pthread_create(&tid2, NULL, thread, NULL);
pthread_join(tid1, NULL);
pthread_join(tid2, NULL);
printf ("1000000 + 1000000 = %d\n", sum);return (0);}
```
![alt text](image\3.png)

# 二、生产者消费者模型
代码及其运行结果:
```
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define BUFFER_SIZE 5
#define NUM_ITEMS 10

int buffer[BUFFER_SIZE];
int count = 0; 
int in = 0;   
int out = 0;  

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond_producer = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond_consumer = PTHREAD_COND_INITIALIZER;


void* producer(void* arg) {
    for (int i = 1; i <= NUM_ITEMS; i++) {
        pthread_mutex_lock(&mutex);
        

        while (count == BUFFER_SIZE) {
            pthread_cond_wait(&cond_producer, &mutex);
        }
        
        buffer[in] = i;
        in = (in + 1) % BUFFER_SIZE;
        count++;
        
        printf("Produced: %d | Buffer size: %d\n", i, count);
        
        pthread_mutex_unlock(&mutex);
        pthread_cond_signal(&cond_consumer); 
        
        usleep(100000); 
    }
    return NULL;
}

void* consumer(void* arg) {
    for (int i = 1; i <= NUM_ITEMS; i++) {
        pthread_mutex_lock(&mutex);
        

        while (count == 0) {
            pthread_cond_wait(&cond_consumer, &mutex);
        }

        int item = buffer[out];
        out = (out + 1) % BUFFER_SIZE;
        count--;
        
        printf("Consumed: %d | Buffer size: %d\n", item, count);
        
        pthread_mutex_unlock(&mutex);
        pthread_cond_signal(&cond_producer); 
        
        usleep(150000); 
    }
    return NULL;
}

int main() {
    pthread_t producer_thread, consumer_thread; 
    pthread_create(&producer_thread, NULL, producer, NULL);
    pthread_create(&consumer_thread, NULL, consumer, NULL);
    
    pthread_join(producer_thread, NULL);
    pthread_join(consumer_thread, NULL);
    
    printf("Production and consumption completed.\n");

    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond_producer);
    pthread_cond_destroy(&cond_consumer);
    
    return 0;
}
```
![alt text](image\4.png)